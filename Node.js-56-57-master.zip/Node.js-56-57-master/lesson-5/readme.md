[Какие бывают варианты размещения сайта на хостинге](./slides/deploy-variants.jpg)

[Как разместить сайт на одном сервере](./slides/variants-deploy-all-in-one.jpg)

[Структура бекенда](./slides/backend-structure.jpg)

[Какие типы баз данных бывают](./slides/database-types.jpg)

[Почему noSQL базы называают документоориентированными](./slides/documents-database-schema.jpg)

[Какие типы баз данных бывают](./slides/database-types.jpg)

[Почему нужно использовать удаленную базу данных](./slides/remote-database.jpg)

[Как работает пакет dotenv](./slides/dotenv-work-schema.jpg)

[Как работает бекенд с Google таблицами](./slides/woork-with-google-sheets.jpg)

[Пример структуры 'схема-модель-коллекция' в жизни](./slides/schema-model-example.jpg)

[Схема-Модель-коллекцция в MongoDB](./slides/schema-model-collection.jpg)

[Как обрабатывается ошибка не найденного маршрута в Express](./slides/express-middleware-not-found-shema.jpg)

[Как Express обрабатывает ошибку, переданную в next](./slides/express-error-handler.jpg)



