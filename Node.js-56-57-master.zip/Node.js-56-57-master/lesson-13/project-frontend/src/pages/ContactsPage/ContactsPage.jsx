import styles from "./contacts-page.module.scss";

const ContactsPage = () => {
    return (
        <div className="container">
            <h1 className="page-title">Cntacts page</h1>
        </div>
    )
}

export default ContactsPage;