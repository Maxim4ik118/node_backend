const NotFoundPage = () => {
    return (
        <div className="container">
            <h1 className="page-title">Not found page</h1>
        </div>
    )
}

export default NotFoundPage;