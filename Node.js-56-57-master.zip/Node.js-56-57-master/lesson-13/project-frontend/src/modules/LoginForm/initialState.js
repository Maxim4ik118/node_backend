const initialState = {
    email: "",
    password: ""
};

export default initialState;