const initialState = {
    name: "",
    email: "",
    password: ""
};

export default initialState;