const initialState =  {
    title: "",
    author: "",
    favorite: false,
}

export default initialState;