[Где применяются веб-сокеты](./slides/websocket-projects.jpg)

[Разница между веб-сокетами и HTTP](./slides/different-between-websockets-and-http.jpg)

[Основные нюансы вет-сокет протокола](./slides/websocket-main-features.jpg)

[Схема взаимодействия клиент-сервер у веб-сокетов](./slides/web-socket-client-server-schema.jpg)

[Принцип работы с каждым отдельным клиентом у веб-сокетов](./slides/web-socket-personal-client-object.jpg)