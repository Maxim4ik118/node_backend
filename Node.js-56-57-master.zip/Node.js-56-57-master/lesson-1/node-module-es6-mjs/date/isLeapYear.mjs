const isLeapYear = (year) => {

}

export default isLeapYear;