[Мотивационная картинка](./slides/motivation-picture.png)

[Причины изучать Node.js](./slides/reasons-learn-nodejs.jpg)

[Как V8 обрабатывает JS-код](./slides/JS-V8-work.jpg)

[Как V8 обрабатывает JS-код, которого нет в документации JS](./slides/JS-V8-setTimeout-work.jpg)

[Структура Node.js](./slides/Nodejs-structure.jpg)

[Проблемы при добавлении библиотек на чистом JS](./slides/add-vanilla-js-library-problems.jpg)

[Структура NPM](./slides/npm-structure.jpg)

[Последовательность шагов при создании проекта](./slides/project-create-steps.jpg)
