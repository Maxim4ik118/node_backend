const getCurrentMonth = require("./getCurrentMonth");
const isLeapYear = require("./isLeapYear");

module.exports = {
    getCurrentMonth,
    isLeapYear,
}

