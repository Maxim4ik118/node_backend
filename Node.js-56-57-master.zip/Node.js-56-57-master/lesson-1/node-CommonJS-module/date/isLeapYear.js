const isLeapYear = (year) => {

}

module.exports = isLeapYear;