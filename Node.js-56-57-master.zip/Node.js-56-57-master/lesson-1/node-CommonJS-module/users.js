// const now = new Date();
// console.log(now);

const admins = ["Alex", "Andrey", "VAsiliy"];

const clients = ["Anna", "Alina", "Tamara"];

const users = {
    admins,
    clients
};

module.exports = users;

