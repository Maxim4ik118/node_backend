const date = new Date();

console.log(`Today is ${date.getFullYear()}`);
