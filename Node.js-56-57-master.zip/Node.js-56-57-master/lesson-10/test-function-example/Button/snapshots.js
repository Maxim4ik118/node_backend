{/* <Button text="Click me" />
<button>Click me</button> */}

const snapshot = `<button>Click me</button>`;

const result = jest.render(<Button text="Click me" />);