const isLeapYear = require("./isLeapYear");

module.exports = {
    isLeapYear
}