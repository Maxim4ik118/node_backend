[Схема взаимодействия клиента и сервера](./slides/Client-Server-schema.jpg)

[Как работают middleware в express](./slides/middleware-work-schema.jpg)

[Как работают middleware в express](./slides/middleware-work-schema.jpg)

[Более подробно - как работают middleware в express](./slides/middleware-work-schema-details.jpg)

[Middleware в express как оглавление записной книжки](./slides/middleware-work-schema-details-2.jpg)

[Middleware в express как набор обязательных действий на ресепшен](./slides/middleware-work-schema-details-3.jpg)

[Что такое CORS - кросс-доменные запросы](./slides/what-is-it-cors.jpg)

[Проблемы с CORS при разработки одновремено фронтенда и бекенда](./slides/fullstack-developer-cors-problem.jpg)

[Проблемы с CORS когда бекенд задеплоен на удаленный сервер](./slides/fullstack-developer-cors-problem-2.jpg)