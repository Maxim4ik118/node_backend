[Где используется работа с файлами в Node.js](./slides/work-with-files-examples.png)
